@echo off
"%~dp0oakblocks.exe" %*
if errorlevel 1 pause
