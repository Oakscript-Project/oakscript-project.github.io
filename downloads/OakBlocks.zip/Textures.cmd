@echo off
"%~dp0oakscript.exe" %* "%~dp0texture-demo.oak"
if errorlevel 1 pause