@echo off
"%~dp0oakscript.exe" %* "%~dp0main.oak"
if errorlevel 1 pause